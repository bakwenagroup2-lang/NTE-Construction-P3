/* NTE Construction Website - Part 3
   Client-side interactions, validation, WhatsApp enquiry preparation,
   email-draft preparation, Leaflet map, gallery and dynamic service filtering.
*/
const WHATSAPP_NUMBER = "27728537594"; // South African format: 27 + number without the leading 0.
const CONTACT_RECIPIENT = "Lesetja321@gmail.com"; // Assignment contact recipient supplied for this project.

document.addEventListener("DOMContentLoaded", () => {
  setupMobileNavigation();
  setupWhatsApp();
  setupFaq();
  setupServiceSearch();
  setupImageLightbox();
  setupForms();
  setupReveal();
  setupBudgetPlanner();
  setupBackToTop();
  setupGautengMap();
});

function whatsappUrl(message) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function setupWhatsApp() {
  const message = "Hello NTE Construction, I would like to enquire about your renovation services.";
  document.querySelectorAll(".whatsapp-float").forEach(link => {
    link.href = whatsappUrl(message);
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });
}

function setupMobileNavigation() {
  const button = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-links");
  if (!button || !nav) return;
  button.addEventListener("click", () => {
    const open = nav.classList.toggle("nav-open");
    button.setAttribute("aria-expanded", String(open));
    button.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
    button.textContent = open ? "×" : "☰";
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("nav-open");
    button.setAttribute("aria-expanded", "false");
    button.setAttribute("aria-label", "Open navigation");
    button.textContent = "☰";
  }));
}

function setupFaq() {
  document.querySelectorAll(".faq-question").forEach(button => {
    button.addEventListener("click", () => {
      const panel = button.nextElementSibling;
      if (!panel) return;
      const open = button.getAttribute("aria-expanded") === "true";
      button.setAttribute("aria-expanded", String(!open));
      panel.hidden = open;
    });
  });
}

function setupServiceSearch() {
  const input = document.querySelector("#service-search");
  const cards = [...document.querySelectorAll(".services-grid .service-card")];
  const buttons = [...document.querySelectorAll("[data-filter]")];
  if (!cards.length) return;
  let category = "all";
  function filterCards() {
    const query = (input?.value || "").toLowerCase().trim();
    let visible = 0;
    cards.forEach(card => {
      const text = (card.dataset.search || card.textContent || "").toLowerCase();
      const matches = (category === "all" || card.dataset.category === category) && text.includes(query);
      card.hidden = !matches;
      if (matches) visible += 1;
    });
    const count = document.querySelector("#service-count");
    const empty = document.querySelector("#no-services");
    if (count) count.textContent = `${visible} service${visible === 1 ? "" : "s"} found`;
    if (empty) empty.hidden = visible !== 0;
  }
  input?.addEventListener("input", filterCards);
  buttons.forEach(button => button.addEventListener("click", () => {
    buttons.forEach(item => {
      item.classList.remove("selected");
      item.setAttribute("aria-pressed", "false");
    });
    button.classList.add("selected");
    button.setAttribute("aria-pressed", "true");
    category = button.dataset.filter || "all";
    filterCards();
  }));
  filterCards();
}

function setupImageLightbox() {
  const images = [...document.querySelectorAll('[data-gallery="true"]')];
  const modal = document.querySelector("#image-lightbox");
  if (!images.length || !modal) return;
  const largeImage = modal.querySelector("img");
  const caption = modal.querySelector(".lightbox-caption");
  const close = modal.querySelector(".lightbox-close");
  if (!largeImage || !caption || !close) return;
  let previous = null;
  function shut() {
    modal.hidden = true;
    document.body.style.overflow = "";
    previous?.focus();
  }
  function show(image) {
    previous = image;
    largeImage.src = image.currentSrc || image.src;
    largeImage.alt = image.alt || "Enlarged renovation project image";
    caption.textContent = image.alt || "Renovation project image";
    modal.hidden = false;
    document.body.style.overflow = "hidden";
    close.focus();
  }
  images.forEach(image => {
    image.addEventListener("click", () => show(image));
    image.addEventListener("keydown", event => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        show(image);
      }
    });
  });
  close.addEventListener("click", shut);
  modal.addEventListener("click", event => { if (event.target === modal) shut(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape" && !modal.hidden) shut(); });
}

function setupForms() {
  const enquiryForm = document.getElementById("enquiry-form");
  const contactForm = document.getElementById("contact-form");

  if (enquiryForm) {
    enquiryForm.addEventListener("submit", event => {
      event.preventDefault();
      clearFormErrors(enquiryForm);
      if (!validate(enquiryForm)) return;
      const message = buildWhatsAppMessage(new FormData(enquiryForm), "enquiry-form");
      showActionLink(enquiryForm, whatsappUrl(message), "Open WhatsApp and send your renovation enquiry", "Your enquiry has been validated. Open WhatsApp, review the message and press Send to submit it.");
    });
    attachLiveValidation(enquiryForm);
  }

  if (contactForm) {
    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      clearFormErrors(contactForm);
      if (!validate(contactForm)) return;
      const data = new FormData(contactForm);
      const subject = `NTE Construction - ${String(data.get("messageType") || "General message")} - ${String(data.get("subject") || "Website message")}`;
      const body = [
        "NTE CONSTRUCTION - WEBSITE CONTACT MESSAGE",
        "",
        `Name: ${data.get("name")}`,
        `Email: ${data.get("email")}`,
        `Phone: ${data.get("phone") || "Not supplied"}`,
        `Subject: ${data.get("subject")}`,
        `Message type: ${data.get("messageType")}`,
        "",
        "Message:",
        data.get("message"),
        "",
        "Consent to be contacted: Yes"
      ].join("\n");
      const mailto = `mailto:${CONTACT_RECIPIENT}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      showActionLink(contactForm, mailto, "Open email to send your message", `Your message has been validated and prepared for ${CONTACT_RECIPIENT}. Select the link below, then press Send in your email application.`);
    });
    attachLiveValidation(contactForm);
  }
}

function showActionLink(form, url, label, message) {
  const status = form.querySelector(".form-status");
  if (!status) return;
  status.className = "form-status info-status";
  status.textContent = message + " ";
  const link = document.createElement("a");
  link.href = url;
  link.textContent = label;
  link.className = "form-action-link";
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  status.append(link);
}

function attachLiveValidation(form) {
  form.querySelectorAll("input, select, textarea").forEach(field => {
    field.addEventListener("input", () => clearField(field));
    field.addEventListener("change", () => clearField(field));
  });
}

function buildWhatsAppMessage(data, formId) {
  const isEnquiry = formId === "enquiry-form";
  const lines = [isEnquiry ? "NTE CONSTRUCTION - RENOVATION ENQUIRY" : "NTE CONSTRUCTION - GENERAL MESSAGE", ""];
  const fields = isEnquiry
    ? [["name", "Full name"], ["email", "Email"], ["phone", "Contact number"], ["location", "Project location"], ["service", "Service required"], ["budget", "Estimated budget"], ["preferredDate", "Preferred start date"], ["message", "Project details"]]
    : [["name", "Full name"], ["email", "Email"], ["phone", "Contact number"], ["subject", "Subject"], ["messageType", "Message type"], ["message", "Message"]];
  fields.forEach(([key, label]) => {
    const value = data.get(key);
    if (value) lines.push(`${label}: ${String(value).trim()}`);
  });
  lines.push("", `Consent to be contacted: ${data.get("consent") ? "Yes" : "No"}`);
  return lines.join("\n");
}

function validate(form) {
  let valid = true;
  form.querySelectorAll('input:not([type="checkbox"]), select, textarea').forEach(field => {
    let message = "";
    const value = String(field.value || "").trim();
    if (field.required && !value) message = "This field is required.";
    else if (field.type === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) message = "Enter a valid email address.";
    else if (field.type === "tel" && value && !/^[0-9+()\s-]{10,20}$/.test(value)) message = "Enter a valid phone number (10–20 characters).";
    else if (field.minLength > 0 && value.length < field.minLength) message = `Enter at least ${field.minLength} characters.`;
    else if (field.type === "date" && value) {
      const chosen = new Date(`${value}T00:00:00`);
      const today = new Date(); today.setHours(0, 0, 0, 0);
      if (chosen < today) message = "Choose today or a future date.";
    }
    if (message) { setError(field, message); valid = false; }
  });
  const consent = form.querySelector('input[name="consent"]');
  if (consent && !consent.checked) {
    const error = form.querySelector(".consent-error");
    if (error) error.textContent = "Please tick the consent box.";
    valid = false;
  }
  if (!valid) {
    form.querySelector(".invalid-field")?.focus();
    const status = form.querySelector(".form-status");
    if (status) { status.className = "form-status error-status"; status.textContent = "Please correct the highlighted fields before continuing."; }
  }
  return valid;
}

function setError(field, message) {
  field.classList.add("invalid-field");
  field.setAttribute("aria-invalid", "true");
  const error = field.closest(".form-group")?.querySelector(".field-error");
  if (error) error.textContent = message;
}

function clearField(field) {
  field.classList.remove("invalid-field");
  field.removeAttribute("aria-invalid");
  const error = field.closest(".form-group")?.querySelector(".field-error");
  if (error) error.textContent = "";
  const consentError = field.closest("form")?.querySelector(".consent-error");
  if (field.name === "consent" && consentError) consentError.textContent = "";
}

function clearFormErrors(form) {
  form.querySelectorAll(".field-error").forEach(error => { error.textContent = ""; });
  form.querySelectorAll(".invalid-field").forEach(field => {
    field.classList.remove("invalid-field");
    field.removeAttribute("aria-invalid");
  });
  const status = form.querySelector(".form-status");
  if (status) { status.textContent = ""; status.className = "form-status"; }
}

function setupReveal() {
  const elements = document.querySelectorAll(".service-card, .feature-card, .mission-card, .contact-card, .process-step");
  if (!("IntersectionObserver" in window)) { elements.forEach(element => element.classList.add("revealed")); return; }
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.classList.add("revealed"); observer.unobserve(entry.target); }
  }), { threshold: 0.12 });
  elements.forEach(element => { element.classList.add("reveal-on-scroll"); observer.observe(element); });
}

function setupBudgetPlanner() {
  const input = document.querySelector("#project-budget");
  const rate = document.querySelector("#contingency-rate");
  const button = document.querySelector("#calculate-budget");
  const result = document.querySelector("#budget-result");
  if (!input || !rate || !button || !result) return;
  const money = value => new Intl.NumberFormat("en-ZA", { style: "currency", currency: "ZAR", maximumFractionDigits: 2 }).format(value);
  button.addEventListener("click", () => {
    const budget = Number(input.value);
    const percentage = Number(rate.value);
    if (!Number.isFinite(budget) || budget <= 0) { result.textContent = "Please enter a budget greater than R0."; input.focus(); return; }
    const reserve = budget * percentage / 100;
    result.textContent = "";
    const rows = [
      ["Planned total budget", money(budget)],
      [`Suggested contingency (${percentage}%)`, money(reserve)],
      ["Remaining amount for planned work", money(budget - reserve)]
    ];
    rows.forEach(([label, value]) => {
      const line = document.createElement("p");
      const strong = document.createElement("strong");
      strong.textContent = `${label}: `;
      line.append(strong, document.createTextNode(value));
      result.append(line);
    });
  });
}

function setupBackToTop() {
  const button = document.querySelector(".back-to-top");
  if (!button) return;
  const update = () => button.classList.toggle("visible", window.scrollY > 350);
  window.addEventListener("scroll", update, { passive: true });
  update();
  button.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

function setupGautengMap() {
  const mapElement = document.getElementById("gauteng-map");
  const fallback = document.getElementById("map-fallback");
  if (!mapElement) return;
  if (typeof L === "undefined") {
    if (fallback) fallback.hidden = false;
    return;
  }
  const map = L.map(mapElement, { scrollWheelZoom: false }).setView([-26.05, 28.15], 9);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 18
  }).addTo(map);
  const areas = [
    { name: "Johannesburg service area", coordinates: [-26.2041, 28.0473] },
    { name: "Centurion service area", coordinates: [-25.8603, 28.1894] },
    { name: "Pretoria service area", coordinates: [-25.7479, 28.2293] }
  ];
  areas.forEach(area => L.marker(area.coordinates).addTo(map).bindPopup(`<strong>${area.name}</strong><br>Indicative Gauteng coverage area.`));
  if (fallback) fallback.hidden = true;
  window.setTimeout(() => map.invalidateSize(), 150);
}
